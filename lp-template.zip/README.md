# LP Template

This is a simple static landing page template for Sasayama Judicial Office.